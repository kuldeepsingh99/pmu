package com.portal.race.util;

public enum RaceOperation {

	NEWRACE,UPDAATERACE,ADDSTARTER,REMOVESTARTER
}
