package com.portal.race.sevice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.portal.race.domain.RaceMaster;
import com.portal.race.domain.RaceStarterMapping;
import com.portal.race.domain.StarterMaster;
import com.portal.race.dto.AddStarterDTO;
import com.portal.race.dto.MessageBusDTO;
import com.portal.race.dto.UpdateRaceDTO;
import com.portal.race.exception.RaceConfigurationException;
import com.portal.race.exception.RaceNotFoundException;
import com.portal.race.exception.StarterNotFoundException;
import com.portal.race.exception.UpdateRaceException;
import com.portal.race.repository.RaceMasterRepository;
import com.portal.race.repository.StarterMasterRepository;
import com.portal.race.util.RaceOperation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RaceMasterService {

	@Autowired
	private RaceMasterRepository racemasterRepository;

	@Autowired
	private RaceStarterMappingService raceStarterMappingService;

	@Autowired
	private StarterMasterRepository starterMasterRepository;

	@Autowired
	private TopicProducer topicProducer;
	
	@Autowired
	private ObjectMapper mapper;
	
	public List<RaceMaster> getAllRacemasters() {
		return racemasterRepository.findAll();
	}

	public Optional<RaceMaster> getRacemasterById(Long id) {
		return racemasterRepository.findById(id);
	}

	/**
	 * This method creates new Race and add at least 3 Starters to Race
	 * @param racemaster RaceMaster
	 * @param starter List of Starters
	 * @return RaceMaster
	 * @throws JsonProcessingException 
	 */
	public RaceMaster createRace(RaceMaster racemaster, List<Long> starter) {

		if (starter.size() < 3) {
			throw new RaceConfigurationException("At least three starters must be mapped to a race.");
		}

		List<StarterMaster> starterList = starterMasterRepository.findAllById(starter);

		if (!starterList.isEmpty() && (starterList.size() > 2 && starterList.size() == starter.size())) {

			RaceMaster savedRace = racemasterRepository.save(racemaster);
			List<RaceStarterMapping> list = new ArrayList<>();
			for (int i = 0; i < starterList.size(); i++) {
				RaceStarterMapping map =  raceStarterMappingService.mapStarterToRace(savedRace, starterList.get(i), i + 1);
				list.add(map);
			}
			savedRace.setRaceStarterMappings(list);
			
			String object;
			try {
				object = mapper.writeValueAsString(savedRace);
				MessageBusDTO message = new MessageBusDTO(RaceOperation.NEWRACE.name(),object);
				topicProducer.send(mapper.writeValueAsString(message));
			} catch (JsonProcessingException e) {
				log.error("Exception occured sending message to Kafka", e);
			}
			return savedRace;
		}
		throw new StarterNotFoundException("Invalid Starter");
	}

	/**
	 * This method add Starter to the Race
	 * @param updateRaceDTO AddStarterDTO
	 * @return true if updated Successfully
	 */
	public Boolean addStarter(AddStarterDTO updateRaceDTO) {

		Optional<RaceMaster> raceMasterOptional = racemasterRepository.findById(updateRaceDTO.getRaceId());
		if (raceMasterOptional.isPresent()) {
			RaceMaster raceMaster = raceMasterOptional.get();

			List<StarterMaster> starterList = starterMasterRepository.findAllById(updateRaceDTO.getStarterId());

			if (!starterList.isEmpty() && starterList.size() == updateRaceDTO.getStarterId().size()) {

				RaceStarterMapping raceMaping = raceStarterMappingService.findMaxStarterNoByRace(raceMaster);
				if (null != raceMaping) {
					int maxStarterNo = raceMaping.getStarterNo();
					
					List<RaceStarterMapping> list = new ArrayList<>();
					for (int i = 0; i < starterList.size(); i++) {
						maxStarterNo = maxStarterNo + 1;
						RaceStarterMapping map = raceStarterMappingService.mapStarterToRace(raceMaster, starterList.get(i), maxStarterNo);
						list.add(map);
					}
					raceMaster.setRaceStarterMappings(list);
					
					String object;
					try {
						object = mapper.writeValueAsString(raceMaster);
						MessageBusDTO message = new MessageBusDTO(RaceOperation.ADDSTARTER.name(),object);
						topicProducer.send(mapper.writeValueAsString(message));
					} catch (JsonProcessingException e) {
						log.error("Exception occured sending message to Kafka", e);
					}
					return true;
				}
			} else {
				throw new UpdateRaceException("Invalid Starter");
			}
		} else {
			throw new RaceNotFoundException("Race Not found");
		}
		return false;
	}
	
	
	/**
	 * This method updates the Race 
	 * @param updateRaceDTO UpdateRaceDTO
	 * @return
	 */
	public Boolean updateRace(UpdateRaceDTO updateRaceDTO) {
		
		Optional<RaceMaster> raceMasterOptional = racemasterRepository.findById(updateRaceDTO.getRaceId());
		if (raceMasterOptional.isPresent()) {
			RaceMaster raceMaster = raceMasterOptional.get();
		
			raceMaster.setRaceDate(updateRaceDTO.getRaceDate() != null ? updateRaceDTO.getRaceDate() : raceMaster.getRaceDate());
			raceMaster.setRaceName(updateRaceDTO.getRaceName() != null ? updateRaceDTO.getRaceName() : raceMaster.getRaceName());
			raceMaster.setRaceNumber(updateRaceDTO.getRaceNo() > 0 ? updateRaceDTO.getRaceNo() : raceMaster.getRaceNumber());
			raceMaster.setStatus(updateRaceDTO.getActive());
			
			racemasterRepository.save(raceMaster);
			
			String object;
			try {
				object = mapper.writeValueAsString(raceMaster);
				MessageBusDTO message = new MessageBusDTO(RaceOperation.UPDAATERACE.name(),object);
				topicProducer.send(mapper.writeValueAsString(message));
			} catch (JsonProcessingException e) {
				log.error("Exception occured sending message to Kafka", e);
			}
			
			return true;
		} else {
			throw new RaceNotFoundException("Race Not found");
		}
	}

	/**
	 * This method Removes the Starters from the Race
	 * @param updateRaceDTO AddStarterDTO
	 * @return
	 */
	@SuppressWarnings("unlikely-arg-type")
	public Boolean removeStarter(AddStarterDTO updateRaceDTO) {
		
		Optional<RaceMaster> raceMasterOptional = racemasterRepository.findById(updateRaceDTO.getRaceId());
		if (raceMasterOptional.isPresent()) {
			RaceMaster raceMaster = raceMasterOptional.get();

			List<StarterMaster> starterList = starterMasterRepository.findAllById(updateRaceDTO.getStarterId());

			if (!starterList.isEmpty() && starterList.size() == updateRaceDTO.getStarterId().size()) {
				
				for(StarterMaster starter: starterList) {
					raceStarterMappingService.deleteByRaceAndStarter(raceMaster, starter);
				}
				
				List<RaceStarterMapping> mapping = raceMaster.getRaceStarterMappings();
				
				mapping.removeAll(starterList);
				raceMaster.setRaceStarterMappings(mapping);
				
				String object;
				try {
					object = mapper.writeValueAsString(raceMaster);
					MessageBusDTO message = new MessageBusDTO(RaceOperation.REMOVESTARTER.name(),object);
					topicProducer.send(mapper.writeValueAsString(message));
				} catch (JsonProcessingException e) {
					log.error("Exception occured sending message to Kafka", e);
				}
				
				return true;
				
			} else {
				throw new StarterNotFoundException("Invalid Starter");
			}
		} else {
			throw new RaceNotFoundException("Race Not found");
		}
	}

	/**
	 * Get all the Races
	 * @return List<RaceMaster>
	 */
	public List<RaceMaster> findAllRaces() {
		return racemasterRepository.findAll();
	}

	/**
	 * Get the Race by Id
	 * @param raceId
	 * @return
	 */
	public RaceMaster getRaceById(Long raceId) {
		
		Optional<RaceMaster> raceMasterOptional = racemasterRepository.findById(Long.valueOf(raceId));
		if(raceMasterOptional.isPresent()) {
			return raceMasterOptional.get();
		}
		
		throw new RaceNotFoundException("Race Not Found");
	}
}
