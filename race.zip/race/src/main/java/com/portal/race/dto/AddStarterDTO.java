package com.portal.race.dto;

import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AddStarterDTO {

	@NotNull(message = "Race Id cannot Empty")
	private long raceId;
	
	@NotNull(message = "Starter cannot be Empty")
	private List<Long> starterId; 
}
