package com.portal.race.util;

import org.springframework.stereotype.Component;

import com.portal.race.domain.RaceMaster;
import com.portal.race.dto.RaceMasterDTO;

@Component
public class RacesUtil {

	public RaceMaster convertToEntity(RaceMasterDTO raceMasterDTO) {
		RaceMaster racemaster = new RaceMaster();
        racemaster.setRaceName(raceMasterDTO.getRaceName());
        racemaster.setRaceNumber(raceMasterDTO.getRaceNo());
        racemaster.setRaceDate(raceMasterDTO.getRaceDate());
        racemaster.setStatus(1);
        return racemaster;
    }
}
