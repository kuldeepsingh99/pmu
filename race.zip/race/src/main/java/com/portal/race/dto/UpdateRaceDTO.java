package com.portal.race.dto;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;

import lombok.Data;

@Data
public class UpdateRaceDTO {

	@NotNull(message = "Race Id cannot Empty")
	private long raceId;
	
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Race name must contain only alphabets and numerals")
	private String raceName;

	@PositiveOrZero(message = "Race number must be a positive integer")
	private int raceNo;
	
	@Future(message = "Race Date must be a future date")
	private Date raceDate;
	
	@NotNull(message = "Race Aactive cannot be Empty")
	private int active;
	
	public int getRaceNo() {
        return raceNo;
    }

    public void setRaceNo(int raceNo) {
        // Apply @PositiveOrZero only if raceNo is not empty
        if (raceNo != 0) {
            this.raceNo = raceNo;
        }
    }
}
