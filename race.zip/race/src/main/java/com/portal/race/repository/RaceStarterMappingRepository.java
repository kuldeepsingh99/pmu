package com.portal.race.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.portal.race.domain.RaceMaster;
import com.portal.race.domain.RaceStarterMapping;

@Repository
public interface RaceStarterMappingRepository extends JpaRepository<RaceStarterMapping, Long> {
	
	@Query("SELECT rsm FROM RaceStarterMapping rsm WHERE rsm.race = :race ORDER BY rsm.starterNo DESC")
    List<RaceStarterMapping> findMaxStarterNoByRace(@Param("race") RaceMaster race);

	@Modifying
	@Query(value = "DELETE FROM race_starter_mapping WHERE race_id = :raceId AND starter_id = :starterId", nativeQuery = true)
	void deleteByRaceAndStarterNative(@Param("raceId") Long raceId, @Param("starterId") Long starterId);


}
