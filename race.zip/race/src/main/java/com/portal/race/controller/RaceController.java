package com.portal.race.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Positive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.portal.race.domain.RaceMaster;
import com.portal.race.dto.AddStarterDTO;
import com.portal.race.dto.RaceMasterDTO;
import com.portal.race.dto.UpdateRaceDTO;
import com.portal.race.exception.RaceConfigurationException;
import com.portal.race.sevice.RaceMasterService;
import com.portal.race.util.RacesUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/")
public class RaceController {

	@Autowired
	RacesUtil racesUtil;

	@Autowired
	RaceMasterService raceMasterService;

	@Operation(description = "Create New Race")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "500", description = "Server Error")
	})
	@PostMapping("races")
	public ResponseEntity<RaceMaster> createRaceWithStarters(@Valid @RequestBody RaceMasterDTO raceMasterDTO)
			throws RaceConfigurationException {

		RaceMaster raceMaster = racesUtil.convertToEntity(raceMasterDTO);

		List<Long> starterId = raceMasterDTO.getStarterId();

		return ResponseEntity.ok(raceMasterService.createRace(raceMaster, starterId));
	}

	@Operation(description = "Update Race")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "404", description = "Race Not Found"),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "500", description = "Server Error")
	})
	@PutMapping("races")
	public ResponseEntity<Boolean> updateRace(@Valid @RequestBody UpdateRaceDTO updateRaceDTO)
			throws RaceConfigurationException {

		return ResponseEntity.ok(raceMasterService.updateRace(updateRaceDTO));
	}

	@Operation(description = "Add Starters to the Race")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "404", description = "Starter or Race Not Found"),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "500", description = "Server Error")
	})
	@PutMapping("starter")
	public ResponseEntity<Boolean> addStarterToRace(@Valid @RequestBody AddStarterDTO updateRaceDTO) {
		return ResponseEntity.ok(raceMasterService.addStarter(updateRaceDTO));
	}

	
	@Operation(description = "Remove Starters from Race")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "404", description = "Starter or Race Not Found"),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "500", description = "Server Error")
	})
	@DeleteMapping("starter")
	public ResponseEntity<Boolean> removeStarterToRace(@Valid @RequestBody AddStarterDTO updateRaceDTO) {
		return ResponseEntity.ok(raceMasterService.removeStarter(updateRaceDTO));
	}

	
	@Operation(description = "Get All Races")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "500", description = "Server Error")
	})
	@GetMapping("races")
	public ResponseEntity<List<RaceMaster>> getAllRaces() {

		return ResponseEntity.ok(raceMasterService.findAllRaces());
	}
	
	@Operation(description = "Get Race By Id")
	@GetMapping("races/{raceId}")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "404", description = "Race Not Found"),
			@ApiResponse(responseCode = "500", description = "Server Error")
	})
	public ResponseEntity<RaceMaster> getRaceById(@Valid @Positive @PathVariable("raceId") Long raceId) {

		return ResponseEntity.ok(raceMasterService.getRaceById(raceId));
	}
	
}
