package com.portal.race.sevice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portal.race.domain.RaceMaster;
import com.portal.race.domain.RaceStarterMapping;
import com.portal.race.domain.StarterMaster;
import com.portal.race.repository.RaceStarterMappingRepository;

@Service
public class RaceStarterMappingService {

	@Autowired
    private RaceStarterMappingRepository raceStarterMappingRepository;

	/**
	 * This method saves Race Starter Mapping
	 * @param race RaceMaster
	 * @param starterMaster StarterMaster
	 * @param starterIndex Starter Index for the Race
	 */
	public RaceStarterMapping mapStarterToRace(RaceMaster race, StarterMaster starterMaster, int starterIndex) {
        RaceStarterMapping raceStarterMapping = new RaceStarterMapping();
        raceStarterMapping.setRace(race);
        raceStarterMapping.setStarter(starterMaster);
        raceStarterMapping.setStarterNo(starterIndex);
        raceStarterMapping.setPosition(0);
        return raceStarterMappingRepository.save(raceStarterMapping);
    }
    
	/**
	 * This method returns the Max Mapping by Starter No
	 * @param race RaceMaster
	 * @return
	 */
    public RaceStarterMapping findMaxStarterNoByRace(RaceMaster race) {
    	
    	List<RaceStarterMapping> mappingList = raceStarterMappingRepository.findMaxStarterNoByRace(race);
    	
    	if(!mappingList.isEmpty()) {
    		return mappingList.get(0);
    	}
		return null;
    }
    
    /**
     * This method Deletes the Race Starter Mapping
     * @param race RaceMaster
     * @param starterMaster StarterMaster
     */
    @Transactional
    public void deleteByRaceAndStarter(RaceMaster race, StarterMaster starterMaster) {
    	
    	raceStarterMappingRepository.deleteByRaceAndStarterNative(race.getId(), starterMaster.getId());
    	
    }
}
