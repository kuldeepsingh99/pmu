package com.portal.race.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.portal.race.domain.StarterMaster;

@Repository
public interface StarterMasterRepository extends JpaRepository<StarterMaster, Long> {
	
}
