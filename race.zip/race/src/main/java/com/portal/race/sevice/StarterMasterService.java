package com.portal.race.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.portal.race.domain.StarterMaster;
import com.portal.race.repository.StarterMasterRepository;

@Service
public class StarterMasterService {

	@Autowired
    private StarterMasterRepository StarterMasterRepository;

	/**
	 * This method gets all the Starter
	 * @return List of starter
	 */
    public List<StarterMaster> getAllStarterMasters() {
        return StarterMasterRepository.findAll();
    }

    public StarterMaster saveStarterMaster(StarterMaster StarterMaster) {
        return StarterMasterRepository.save(StarterMaster);
    }

    public void deleteStarterMaster(Long id) {
        StarterMasterRepository.deleteById(id);
    }
}
