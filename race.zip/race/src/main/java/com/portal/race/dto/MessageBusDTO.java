package com.portal.race.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MessageBusDTO {
	
	public String operation;
	public String object;

}
