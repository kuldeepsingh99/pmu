package com.portal.race.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.portal.race.domain.RaceMaster;

@Repository
public interface RaceMasterRepository extends JpaRepository<RaceMaster, Long>{

}
