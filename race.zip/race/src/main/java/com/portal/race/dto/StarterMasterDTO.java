package com.portal.race.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class StarterMasterDTO {

	@NotBlank(message = "Starter name cannot be blank")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Starter name must contain only alphabets and numerals")
	private String starterName;
	
	@Positive(message = "Starter number must be a positive integer")
    private String starterNumber;
}
