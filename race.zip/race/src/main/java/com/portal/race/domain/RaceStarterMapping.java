package com.portal.race.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@Entity
@Table(name = "race_starter_mapping")
@Data
public class RaceStarterMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@JsonBackReference
	@ManyToOne
    @JoinColumn(name = "race_id", nullable = false)
    private RaceMaster race;

    @Column(name = "starter_no", nullable = false)
    private int starterNo;

    @ManyToOne
    @JoinColumn(name = "starter_id", nullable = false)
    private StarterMaster starter;

    @Column(name = "position")
    private Integer position;
	
}
