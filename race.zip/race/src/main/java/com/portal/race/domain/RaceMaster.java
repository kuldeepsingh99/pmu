package com.portal.race.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "racemaster")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RaceMaster implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "race_name", nullable = false)
	private String raceName;
	
	@Column(name = "race_no", nullable = false)
	private int raceNumber;

	@Column(name = "race_date", nullable = false)
	private Date raceDate;
	
	@Column(name = "status", nullable = false)
	private int status;

	@JsonManagedReference
	@OneToMany(mappedBy = "race", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RaceStarterMapping> raceStarterMappings;
}
