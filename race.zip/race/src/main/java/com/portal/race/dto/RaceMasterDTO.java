package com.portal.race.dto;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class RaceMasterDTO {

	@NotNull(message = "Race name cannot be blank")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Race name must contain only alphabets and numerals")
	private String raceName;

	@Positive(message = "Race number must be a positive integer")
	private int raceNo;
	
	@NotNull(message = "Race Date cannot be blank")
	@Future(message = "Race Date must be a future date")
	private Date raceDate;
	
	@NotNull(message = "Starter cannot be Empty")
	@Size(min = 3, message = "At least 3 starters are required")
	private List<Long> starterId;

}
