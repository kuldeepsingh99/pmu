package com.portal.race.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.portal.race.domain.RaceMaster;
import com.portal.race.domain.RaceStarterMapping;
import com.portal.race.domain.StarterMaster;
import com.portal.race.exception.RaceNotFoundException;
import com.portal.race.exception.StarterNotFoundException;
import com.portal.race.repository.RaceMasterRepository;
import com.portal.race.repository.StarterMasterRepository;
import com.portal.race.sevice.RaceMasterService;
import com.portal.race.sevice.RaceStarterMappingService;
import com.portal.race.sevice.TopicProducer;

@ExtendWith(MockitoExtension.class)
public class RaceMasterServiceTest {

	@Mock
    private RaceMasterRepository racemasterRepository;

    @InjectMocks
    private RaceMasterService raceMasterService;

    @Mock
    private RaceStarterMappingService raceStarterMappingService;

    @Mock
    private TopicProducer topicProducer;
    
    @Mock
    ObjectMapper mapper;
    
    @Mock
    private StarterMasterRepository starterMasterRepository;

    @Test
    public void testGetRaceById_WhenRaceExists() {
        RaceMaster expectedRace = new RaceMaster();
        when(racemasterRepository.findById(anyLong())).thenReturn(Optional.of(expectedRace));

        RaceMaster result = raceMasterService.getRaceById(1L);

        assertEquals(expectedRace, result);
    }

    @Test
    public void testGetRaceById_WhenRaceDoesNotExist() {
        when(racemasterRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(RaceNotFoundException.class, () -> raceMasterService.getRaceById(1L));
    }
    
    @Test
    public void testFindAllRaces_WhenRacesExist() {
        
    	RaceMaster race1 = new RaceMaster(1L, "TestRace1", 100, new Date(), 1, new ArrayList<RaceStarterMapping>());
        RaceMaster race2 = new RaceMaster(1L, "TestRace2", 101, new Date(), 1, new ArrayList<RaceStarterMapping>());
        List<RaceMaster> expectedRaces = Arrays.asList(race1, race2);
        when(racemasterRepository.findAll()).thenReturn(expectedRaces);

        List<RaceMaster> result = raceMasterService.findAllRaces();
        
        assertEquals(expectedRaces, result);
    }

    @Test
    public void testFindAllRaces_WhenNoRacesExist() {
        when(racemasterRepository.findAll()).thenReturn(Collections.emptyList());

        // Call the method
        List<RaceMaster> result = raceMasterService.findAllRaces();

        // Verify that the result is an empty list
        assertEquals(Collections.emptyList(), result);
    }
    
    @Test
    public void testCreateRace_WithValidInput() {
        
    	List<Long> starterIds = Arrays.asList(1L, 2L, 3L);
        List<StarterMaster> starterList = Arrays.asList(
        		new StarterMaster(1L, "Jockey1", "100", 1),
        		new StarterMaster(2L, "Jockey2", "101", 1),
        		new StarterMaster(3L, "Jockey3", "102", 1));
        when(starterMasterRepository.findAllById(starterIds)).thenReturn(starterList);

        RaceMaster racemaster = new RaceMaster(1L, "TestRace1", 100, new Date(), 1, new ArrayList<RaceStarterMapping>());
        when(racemasterRepository.save(any(RaceMaster.class))).thenReturn(racemaster);

        
        RaceStarterMapping raceStarterMapping = new RaceStarterMapping();
        when(raceStarterMappingService.mapStarterToRace(any(RaceMaster.class), any(StarterMaster.class), anyInt()))
                .thenReturn(raceStarterMapping);

        RaceMaster result = raceMasterService.createRace(racemaster, starterIds);

        assertEquals(racemaster, result);
        verify(topicProducer, times(1)).send(any());
    }

    @Test
    public void testCreateRace_WithInvalidStarter() {
        List<Long> starterIds = Arrays.asList(1L, 2L, 3L);
        when(starterMasterRepository.findAllById(starterIds)).thenReturn(Collections.emptyList());

        assertThrows(StarterNotFoundException.class, () -> raceMasterService.createRace(new RaceMaster(), starterIds));
    }

    @Test
    public void testCreateRace_WithInsufficientStarters() {
        List<Long> starterIds = Arrays.asList(1L, 2L, 3L);
        
        List<StarterMaster> starterList = Arrays.asList(
        		new StarterMaster(1L, "Jockey1", "100", 1),
        		new StarterMaster(2L, "Jockey2", "101", 1));
        		
        when(starterMasterRepository.findAllById(starterIds)).thenReturn(starterList);

        assertThrows(StarterNotFoundException.class, () -> raceMasterService.createRace(new RaceMaster(), starterIds));
    }
}
