DROP TABLE IF EXISTS `racemaster`;
CREATE TABLE IF NOT EXISTS `racemaster` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `race_name` varchar(50) NOT NULL,
  `race_no` int(11) NOT NULL,
  `race_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `race_name_race_no_race_date` (`race_name`,`race_no`,`race_date`)
) ENGINE=InnoDB AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `startermaster`;
CREATE TABLE IF NOT EXISTS `startermaster` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `starter_name` varchar(50) NOT NULL,
  `starter_no` int(11) NOT NULL,
  `active` tinyint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

DROP TABLE IF EXISTS `race_starter_mapping`;
CREATE TABLE IF NOT EXISTS `race_starter_mapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `race_id` bigint(20) NOT NULL,
  `starter_no` int(11) NOT NULL,
  `starter_id` bigint(20) NOT NULL DEFAULT '0',
  `position` tinyint(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `race_id_starter_id` (`race_id`,`starter_id`),
  KEY `FK_race_starter_mapping_startermaster` (`starter_id`),
  CONSTRAINT `FK_race_starter_mapping_racemaster` FOREIGN KEY (`race_id`) REFERENCES `racemaster` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_race_starter_mapping_startermaster` FOREIGN KEY (`starter_id`) REFERENCES `startermaster` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1;


INSERT INTO `startermaster` (`id`, `starter_name`, `starter_no`, `active`) VALUES
	(1, 'Jockey 1', 100, 1),
	(2, 'Jockey 2', 101, 1),
	(3, 'Jockey 3', 102, 1),
	(4, 'Jockey 4', 103, 1),
	(5, 'Jockey 5', 105, 1);